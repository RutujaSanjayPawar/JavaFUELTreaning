package com.example.htmlmovisportdisplay;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HtmlmovisportdisplayApplicationTests {

	@Test
	void contextLoads() {
	}

}
