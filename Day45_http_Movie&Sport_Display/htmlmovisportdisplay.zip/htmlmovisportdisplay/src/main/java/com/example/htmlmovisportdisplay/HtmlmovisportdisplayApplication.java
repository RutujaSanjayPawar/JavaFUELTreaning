package com.example.htmlmovisportdisplay;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HtmlmovisportdisplayApplication {

	public static void main(String[] args) {
		SpringApplication.run(HtmlmovisportdisplayApplication.class, args);
	}

}
