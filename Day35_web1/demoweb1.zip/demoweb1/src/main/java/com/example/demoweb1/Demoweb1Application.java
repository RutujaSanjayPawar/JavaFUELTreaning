package com.example.demoweb1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demoweb1Application {

	public static void main(String[] args) {
		SpringApplication.run(Demoweb1Application.class, args);
	}

}
