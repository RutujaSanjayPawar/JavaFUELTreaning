package com.example.webmoviesportpage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebmoviesportpageApplicationTests {

	@Test
	void contextLoads() {
	}

}
