package com.example.webmoviesportpage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebmoviesportpageApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebmoviesportpageApplication.class, args);
	}

}
