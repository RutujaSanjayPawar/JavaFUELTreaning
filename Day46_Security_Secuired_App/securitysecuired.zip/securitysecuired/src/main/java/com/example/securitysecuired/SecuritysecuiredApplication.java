package com.example.securitysecuired;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecuritysecuiredApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecuritysecuiredApplication.class, args);
	}

}
