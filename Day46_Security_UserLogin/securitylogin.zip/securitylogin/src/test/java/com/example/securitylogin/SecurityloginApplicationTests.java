package com.example.securitylogin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecurityloginApplicationTests {

	@Test
	void contextLoads() {
	}

}
