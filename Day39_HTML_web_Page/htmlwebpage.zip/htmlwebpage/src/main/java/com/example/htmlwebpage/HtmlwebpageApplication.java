package com.example.htmlwebpage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HtmlwebpageApplication {

	public static void main(String[] args) {
		SpringApplication.run(HtmlwebpageApplication.class, args);
	}

}
