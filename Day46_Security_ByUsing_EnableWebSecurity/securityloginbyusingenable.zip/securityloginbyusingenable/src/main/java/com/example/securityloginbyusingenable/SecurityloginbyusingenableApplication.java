package com.example.securityloginbyusingenable;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecurityloginbyusingenableApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecurityloginbyusingenableApplication.class, args);
	}

}
