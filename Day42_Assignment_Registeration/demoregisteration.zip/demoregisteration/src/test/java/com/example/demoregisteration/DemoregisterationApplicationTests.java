package com.example.demoregisteration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoregisterationApplicationTests {

	@Test
	void contextLoads() {
	}

}
