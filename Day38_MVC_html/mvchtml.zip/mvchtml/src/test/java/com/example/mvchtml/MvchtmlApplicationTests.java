package com.example.mvchtml;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MvchtmlApplicationTests {

	@Test
	void contextLoads() {
	}

}
