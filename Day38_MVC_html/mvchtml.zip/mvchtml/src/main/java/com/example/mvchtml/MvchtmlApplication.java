package com.example.mvchtml;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MvchtmlApplication {

	public static void main(String[] args) {
		SpringApplication.run(MvchtmlApplication.class, args);
	}

}
