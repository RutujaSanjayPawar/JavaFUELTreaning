package com.example.jpqlsingleresultlist;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpqlsingleresultlistApplicationTests {

	@Test
	void contextLoads() {
	}

}
