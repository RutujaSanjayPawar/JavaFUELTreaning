package com.example.securityunsecured;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecurityunsecuredApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecurityunsecuredApplication.class, args);
	}

}
