package com.example.securityunsecured;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecurityunsecuredApplicationTests {

	@Test
	void contextLoads() {
	}

}
