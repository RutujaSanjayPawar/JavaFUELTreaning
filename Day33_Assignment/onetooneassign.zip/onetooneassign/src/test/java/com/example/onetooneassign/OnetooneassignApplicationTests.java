package com.example.onetooneassign;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnetooneassignApplicationTests {

	@Test
	void contextLoads() {
	}

}
