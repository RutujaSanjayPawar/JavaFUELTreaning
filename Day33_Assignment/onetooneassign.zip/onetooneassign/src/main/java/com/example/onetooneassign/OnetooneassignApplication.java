package com.example.onetooneassign;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnetooneassignApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnetooneassignApplication.class, args);
	}

}
