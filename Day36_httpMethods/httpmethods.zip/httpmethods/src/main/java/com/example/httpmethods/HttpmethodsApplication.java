package com.example.httpmethods;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HttpmethodsApplication {

	public static void main(String[] args) {
		SpringApplication.run(HttpmethodsApplication.class, args);
	}

}
